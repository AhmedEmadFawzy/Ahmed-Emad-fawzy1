import sqlite3
import os
from flask import Flask, render_template, redirect, request, make_response, url_for, flash, send_file, session
from io import BytesIO
from werkzeug.utils import secure_filename
import hashlib
import logging
from authlib.integrations.flask_client import OAuth
from setup import start_db
from check import generate_token, check_token
import pyotp
import qrcode
import base64
import re
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization
from cryptography.exceptions import InvalidSignature

# إعدادات الملفات المرفوعة
UPLOAD_FOLDER = 'A:/Secure-Document-Management-System-main/files'
ALLOWED_EXTENSIONS = {
    'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx',
    'csv', 'mp3', 'mp4', 'zip', 'rar', 'svg', 'xml', 'json', 'html', 'css', 'js', 'py'
}

# إعداد التطبيق
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# إعداد OAuth
oauth = OAuth(app)

# إعداد Google OAuth
google = oauth.register(
    name='google',
    client_id='77582575871-9p0b507jbrkk7iq0je1lc8sfq163gjuh.apps.googleusercontent.com',
    client_secret='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',
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    access_token_url='https://accounts.google.com/o/oauth2/token',
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    client_kwargs={'scope': 'openid email profile'},
    jwks_uri='https://www.googleapis.com/oauth2/v3/certs'
)

# إعداد GitHub OAuth
github = oauth.register(
    name='github',
    client_id='Ov23licG05710mt5cqWC',
    client_secret='540ef8b7ac11c50834e3a7ec4b112428579680a4',
    authorize_url='https://github.com/login/oauth/authorize',
    access_token_url='https://github.com/login/oauth/access_token',
    api_base_url='https://api.github.com/',
    client_kwargs={'scope': 'user:email read:user'}
)

# إعداد Okta OAuth
okta = oauth.register(
    name='okta',
    client_id='0oaou71qhoxWNwRJW5d7',
    client_secret='XHkdXomc9Vw6zMY_U5MoUYHGuDOdFiCES6gkCgkGRq2im0f281KuJObwSe9wsGh8',
    authorize_url='https://dev-34011733.okta.com/oauth2/v1/authorize',
    access_token_url='https://dev-34011733.okta.com/oauth2/v1/token',
    api_base_url='https://dev-34011733.okta.com/oauth2/v1/',
    client_kwargs={'scope': 'openid profile email'},
    jwks_uri='https://dev-34011733.okta.com/oauth2/v1/keys'
)

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
user = ['']

# دوال مساعدة للتشفير والتوقيع
def generate_keys():
    # Generate Fernet key for encryption
    encryption_key = Fernet.generate_key()
    fernet = Fernet(encryption_key)
    
    # Generate RSA key pair for digital signatures
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    
    # Serialize keys
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
format=serialization.PublicFormat.SubjectPublicKeyInfo    )
    
    return encryption_key, private_pem, public_pem
def encrypt_file(file_data, encryption_key):
    fernet = Fernet(encryption_key)
    return fernet.encrypt(file_data)

def decrypt_file(encrypted_data, encryption_key):
    fernet = Fernet(encryption_key)
    return fernet.decrypt(encrypted_data)

def sign_file(file_data, private_key_pem):
    private_key = serialization.load_pem_private_key(
        private_key_pem,
        password=None
    )
    signature = private_key.sign(
        file_data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature

def verify_signature(file_data, signature, public_key_pem):
    public_key = serialization.load_pem_public_key(public_key_pem)
    try:
        public_key.verify(
            signature,
            file_data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True
    except InvalidSignature:
        return False

# دالة لتحديث مفاتيح المستخدمين الحاليين
def update_user_keys():
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID FROM Users WHERE encryption_key IS NULL OR private_key IS NULL OR public_key IS NULL")
        users = cursor.fetchall()
        for (work_id,) in users:
            encryption_key, private_key, public_key = generate_keys()
            cursor.execute(
                "UPDATE Users SET encryption_key = ?, private_key = ?, public_key = ? WHERE WORKID = ?",
                (encryption_key, private_key, public_key, work_id)
            )
        conn.commit()
        logging.info(f"Updated keys for {len(users)} existing users")
    except sqlite3.Error as e:
        logging.error(f"Database Error during key update: {e}")
        conn.rollback()
    finally:
        conn.close()

# دوال مساعدة للـ 2FA
def generate_totp_secret():
    return pyotp.random_base32()

def generate_qr_code(work_id, secret):
    totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(name=work_id, issuer_name="SecureDocSystem")
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(totp_uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    return img_str

# دالة للتحقق من الدور
def get_user_role(work_id):
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT Role FROM Users WHERE WORKID = ?", (work_id,))
        result = cursor.fetchone()
        return result[0] if result else None
    except sqlite3.Error as e:
        logging.error(f"Database Error during get_user_role: {e}")
        return None
    finally:
        conn.close()

# الصفحة الرئيسية
@app.route('/')
def front_page():
    return render_template('index.html')

# اختيار الدور
@app.route('/select_role', methods=['GET'])
def select_role():
    role = request.args.get('role')
    if role not in ['Admin', 'User', 'Manager']:
        flash('دور غير صالح!')
        logging.warning(f"Invalid role selected: {role}")
        return redirect(url_for('front_page'))
    session['selected_role'] = role
    logging.debug(f"Role selected: {role}")
    return redirect(url_for('signup'))

# تسجيل الدخول
@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        con = sqlite3.connect('database.db', timeout=10)
        try:
            WorkID = request.form['WorkID']
            Password = request.form['Password']
            hashed_password = hashlib.sha256(Password.encode()).hexdigest()

            cur = con.cursor()
            cur.execute("SELECT * FROM Users WHERE WORKID = ? AND Password = ?", (WorkID, hashed_password))
            rows = cur.fetchall()
            if len(rows) == 0:
                logging.warning(f"Login failed for WorkID {WorkID}: No matching user")
                return render_template("NoMatchingUser.html")

            session['pending_work_id'] = WorkID
            user[0] = WorkID
            logging.debug(f"Login successful, WorkID: {WorkID}, user[0]: {user[0]}")

            cur.execute("SELECT secret_key FROM Users WHERE WORKID = ?", (WorkID,))
            secret_key = cur.fetchone()[0]

            if not secret_key:
                logging.debug(f"No 2FA secret for WorkID {WorkID}, redirecting to setup_2fa")
                return redirect(url_for('setup_2fa'))
            else:
                logging.debug(f"2FA secret found for WorkID {WorkID}, redirecting to verify_2fa")
                return redirect(url_for('verify_2fa'))

        except sqlite3.Error as e:
            logging.error(f"Database Error during login: {e}")
            return render_template("Error.html")
        finally:
            con.close()
    return render_template('Login.html')

# إعداد الـ 2FA
@app.route('/setup_2fa', methods=['GET', 'POST'])
def setup_2fa():
    if 'pending_work_id' not in session:
        logging.warning("No pending_work_id in session, redirecting to login")
        return redirect(url_for('login'))

    work_id = session['pending_work_id']
    
    if '2fa_secret' not in session:
        session['2fa_secret'] = generate_totp_secret()

    secret = session['2fa_secret']

    if request.method == 'POST':
        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("UPDATE Users SET secret_key = ? WHERE WORKID = ?", (secret, work_id))
            conn.commit()
            logging.info(f"2FA secret set for WorkID {work_id}: {secret}")
            session.pop('2fa_secret', None)
            return redirect(url_for('verify_2fa'))
        except sqlite3.Error as e:
            logging.error(f"Database Error during 2FA setup: {e}")
            conn.rollback()
            flash('حدث خطأ في إعداد التحقق الثنائي، حاول مرة أخرى')
            return render_template('Error.html')
        finally:
            conn.close()

    qr_code = generate_qr_code(work_id, secret)
    return render_template('setup_2fa.html', qr_code=qr_code, work_id=work_id)

# التحقق من الـ 2FA
@app.route('/verify_2fa', methods=['GET', 'POST'])
def verify_2fa():
    if 'pending_work_id' not in session:
        logging.warning("No pending_work_id in session, redirecting to login")
        return redirect(url_for('login'))

    work_id = session['pending_work_id']
    if request.method == 'POST':
        otp = request.form.get('otp', '').strip()
        if not otp:
            logging.warning(f"No OTP provided for WorkID {work_id}")
            flash('يرجى إدخال كود التحقق!')
            return render_template('verify_2fa.html')

        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT secret_key, Role FROM Users WHERE WORKID = ?", (work_id,))
            result = cursor.fetchone()
            if not result or not result[0]:
                logging.error(f"No secret_key found for WorkID {work_id}")
                flash('خطأ في إعداد التحقق الثنائي، يرجى إعادة الإعداد')
                return redirect(url_for('setup_2fa'))

            secret_key, role = result
            logging.debug(f"Verifying OTP for WorkID {work_id}, Role: {role}, secret_key: {secret_key}")

            totp = pyotp.TOTP(secret_key)
            if totp.verify(otp):
                token = generate_token(work_id)
                logging.debug(f"Generated token for WorkID {work_id}: {token}")
                response = make_response(redirect(url_for(f"{role}Main")))
                response.set_cookie('AuthToken', token, max_age=86400, httponly=True)
                user[0] = work_id
                session.pop('pending_work_id', None)
                logging.info(f"2FA verified for WorkID {work_id}, redirecting to {role}Main")
                return response
            else:
                logging.warning(f"Invalid OTP for WorkID {work_id}: {otp}")
                flash('كود التحقق غير صحيح!')
                return render_template('verify_2fa.html')

        except sqlite3.Error as e:
            logging.error(f"Database Error during 2FA verification: {e}")
            flash('حدث خطأ في قاعدة البيانات، حاول مرة أخرى')
            return render_template('Error.html')
        finally:
            conn.close()

    return render_template('verify_2fa.html')

# صفحة التسجيل
@app.route('/signup', methods=['POST', 'GET'])
def signup():
    selected_role = session.get('selected_role', 'User')
    logging.debug(f"Rendering signup page with role: {selected_role}")
    return render_template('SignUp.html', selected_role=selected_role)

# التحقق من التسجيل
@app.route('/signupvalid', methods=['POST', 'GET'])
def signupvalid():
    if request.method == 'POST':
        con = sqlite3.connect('database.db', timeout=10)
        try:
            firstName = request.form.get('First')
            lastName = request.form.get('Last')
            WorkID = request.form.get('WorkID')
            password = request.form.get('Password')
            confirm_pass = request.form.get('ConfirmPassword')
            selected_role = session.get('selected_role', 'User')

            logging.debug(f"Attempting signup for WorkID: {WorkID}, Role: {selected_role}")

            if not all([firstName, lastName, WorkID, password, confirm_pass]):
                flash('يرجى ملء جميع الحقول!')
                logging.warning(f"Missing fields for WorkID {WorkID}")
                return redirect(url_for('signup'))

            work_id_pattern = r'^(A|U|M)\d{8}$'
            if not re.match(work_id_pattern, WorkID):
                flash(f'معرف العمل يجب أن يبدأ بحرف {"A" if selected_role == "Admin" else "M" if selected_role == "Manager" else "U"} متبوع بـ 8 أرقام بالضبط!')
                logging.warning(f"Invalid WorkID format: {WorkID} for role {selected_role}")
                return redirect(url_for('signup'))

            if selected_role == 'Admin' and not WorkID.startswith('A'):
                flash('معرف العمل يجب أن يبدأ بحرف A للأدمن!')
                logging.warning(f"Invalid WorkID {WorkID} for Admin role")
                return redirect(url_for('signup'))
            elif selected_role == 'Manager' and not WorkID.startswith('M'):
                flash('معرف العمل يجب أن يبدأ بحرف M للمدير!')
                logging.warning(f"Invalid WorkID {WorkID} for Manager role")
                return redirect(url_for('signup'))
            elif selected_role == 'User' and not WorkID.startswith('U'):
                flash('معرف العمل يجب أن يبدأ بحرف U للمستخدم!')
                logging.warning(f"Invalid WorkID {WorkID} for User role")
                return redirect(url_for('signup'))

            if password != confirm_pass:
                flash('كلمات المرور غير متطابقة!')
                logging.warning(f"Password mismatch for WorkID {WorkID}")
                return redirect(url_for('signup'))

            hashed_password = hashlib.sha256(password.encode()).hexdigest()
            user[0] = WorkID

            # Generate encryption and signature keys
            encryption_key, private_key, public_key = generate_keys()

            with con:
                cur = con.cursor()
                cur.execute("SELECT WORKID FROM ValidWorkID WHERE WORKID = ?", (WorkID,))
                valid_work_id = cur.fetchone()
                if not valid_work_id:
                    logging.warning(f"WorkID {WorkID} not found in ValidWorkID")
                    flash('معرف العمل غير صالح!')
                    return render_template('InvalidWorkID.html')

                cur.execute("SELECT WORKID FROM Users WHERE WORKID = ?", (WorkID,))
                existing_user = cur.fetchone()
                if existing_user:
                    logging.warning(f"WorkID {WorkID} already exists in Users")
                    flash('معرف العمل مستخدم بالفعل!')
                    return render_template('InvalidWorkID.html')

                cur.execute(
                    "INSERT INTO Users (WORKID, Password, First, Last, Role, secret_key, encryption_key, private_key, public_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (WorkID, hashed_password, firstName, lastName, selected_role, None, encryption_key, private_key, public_key)
                )
                cur.execute(
                    "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                    ('signup', WorkID, WorkID)
                )
                con.commit()
                logging.info(f"User {WorkID} successfully registered with encryption and signature keys")
                flash('تم التسجيل بنجاح، يرجى تسجيل الدخول')
                return redirect(url_for('login'))

        except sqlite3.Error as e:
            logging.error(f"Database Error during signup: {e}")
            con.rollback()
            flash('حدث خطأ في قاعدة البيانات، حاول مرة أخرى')
            return render_template('Error.html')
        finally:
            con.close()
    return redirect(url_for('signup'))

# الصفحة الرئيسية للمستخدم
@app.route('/UserMainPage', methods=['POST', 'GET'])
def UserMain():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for UserMainPage, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for UserMainPage, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'User':
        logging.warning(f"User {user[0]} with role {role} attempted to access UserMainPage")
        return redirect(url_for(f"{role}Main"))

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cur = conn.cursor()
        cur.execute("SELECT FileId, FileName, WorkID FROM Files ORDER BY FileId DESC")
        files = cur.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Database Error in UserMain: {e}")
        return render_template('Error.html')
    finally:
        conn.close()
    return render_template('UserMainPage.html', Files=files)

# الصفحة الرئيسية للمدير
@app.route('/ManagerMainPage', methods=['POST', 'GET'])
def ManagerMain():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for ManagerMainPage, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for ManagerMainPage, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Manager':
        logging.warning(f"User {user[0]} with role {role} attempted to access ManagerMainPage")
        return redirect(url_for(f"{role}Main"))

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cur = conn.cursor()
        cur.execute("SELECT FileId, FileName, WorkID FROM Files ORDER BY FileId DESC")
        files = cur.fetchall()
        cur.execute("SELECT WORKID, First, Last, Role FROM Users")
        users = cur.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Database Error in ManagerMain: {e}")
        return render_template('Error.html')
    finally:
        conn.close()
    return render_template('ManagerMainPage.html', Files=files, Users=users)

# الصفحة الرئيسية للأدمن
@app.route('/AdminMainPage', methods=['POST', 'GET'])
def AdminMain():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for AdminMainPage, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for AdminMainPage, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Admin':
        logging.warning(f"User {user[0]} with role {role} attempted to access AdminMainPage")
        return redirect(url_for(f"{role}Main"))

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cur = conn.cursor()
        cur.execute("SELECT WORKID, First, Last, Role FROM Users")
        users = cur.fetchall()
        cur.execute("SELECT FileId, FileName, WorkID FROM Files ORDER BY FileId DESC")
        files = cur.fetchall()
    except sqlite3.Error as e:
        logging.error(f"Database Error in AdminMain: {e}")
        return render_template('Error.html')
    finally:
        conn.close()
    return render_template('AdminMainPage.html', Users=users, Files=files)

# التحقق من نوع الملف
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# رفع ملف
@app.route('/uploadfile', methods=['POST', 'GET'])
def uploadfile():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for uploadfile, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for uploadfile, user: {user[0]}")
        return render_template('TokenError.html')

    if request.method == 'POST':
        if 'file' not in request.files:
            flash('لا يوجد ملف مرفق')
            return redirect(request.url)

        file = request.files['file']
        if file.filename == '':
            flash('لم يتم اختيار ملف')
            return redirect(request.url)

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_data = file.read()
            if not file_data:
                flash('الملف المرفوع فارغ!')
                logging.warning(f"Empty file uploaded by WorkID {user[0]}")
                return redirect(request.url)

            conn = sqlite3.connect('database.db', timeout=10)
            try:
                cursor = conn.cursor()
                # Get user's encryption and private keys
                cursor.execute("SELECT encryption_key, private_key FROM Users WHERE WORKID = ?", (user[0],))
                result = cursor.fetchone()
                if not result:
                    logging.error(f"No user found for WorkID {user[0]}")
                    flash('خطأ في استرجاع بيانات المستخدم')
                    return render_template('Error.html')

                encryption_key, private_key = result
                if not encryption_key or not private_key:
                    logging.error(f"Missing keys for WorkID {user[0]}: encryption_key={encryption_key}, private_key={private_key}")
                    flash('مفاتيح التشفير أو التوقيع مفقودة')
                    return render_template('Error.html')

                # Encrypt file data
                try:
                    encrypted_data = encrypt_file(file_data, encryption_key)
                except Exception as e:
                    logging.error(f"Encryption Error during file upload for WorkID {user[0]}: {e}")
                    flash('خطأ في تشفير الملف')
                    raise

                # Sign file data
                try:
                    signature = sign_file(file_data, private_key)
                except Exception as e:
                    logging.error(f"Signing Error during file upload for WorkID {user[0]}: {e}")
                    flash('خطأ في توقيع الملف')
                    raise

                cursor.execute(
                    "INSERT INTO Files (FileName, FileData, WorkID, Signature) VALUES (?, ?, ?, ?)",
                    (filename, encrypted_data, user[0], signature)
                )
                cursor.execute(
                    "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                    ('upload_file', user[0], user[0])
                )
                conn.commit()
                logging.info(f"File {filename} uploaded by WorkID {user[0]}")
                flash(f'تم رفع الملف {filename} بنجاح!')
            except sqlite3.Error as e:
                logging.error(f"Database Error during file upload: {e}")
                conn.rollback()
                flash('حدث خطأ في رفع الملف، حاول مرة أخرى')
                return render_template('Error.html')
            except Exception as e:
                logging.error(f"Encryption/Signing Error during file upload: {e}")
                conn.rollback()
                flash('حدث خطأ في تشفير أو توقيع الملف')
                return render_template('Error.html')
            finally:
                conn.close()
        else:
            flash('نوع الملف غير مدعوم! الرجاء اختيار ملف بصيغة مدعومة.')
            logging.warning(f"Unsupported file type: {file.filename}")
            return redirect(request.url)

        role = get_user_role(user[0])
        return redirect(url_for(f"{role}Main"))

    return render_template('UploadFile.html')

# تحميل ملف
@app.route('/download/<int:file_id>')
def downloadfile(file_id):
    session_token = request.cookies.get('AuthToken')
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for downloadfile, user: {user[0]}")
        return render_template('TokenError.html')

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT FileId, FileName, FileData, WorkID, Signature FROM Files WHERE FileId = ?", (file_id,))
        file = cursor.fetchone()
        if file:
            file_id, filename, encrypted_data, work_id, signature = file
            # Get user's encryption and public keys
            cursor.execute("SELECT encryption_key, public_key FROM Users WHERE WORKID = ?", (work_id,))
            result = cursor.fetchone()
            if not result:
                logging.error(f"No user found for WorkID {work_id}")
                flash('خطأ في استرجاع بيانات المستخدم')
                return render_template('Error.html')

            encryption_key, public_key = result
            # Decrypt file data
            try:
                decrypted_data = decrypt_file(encrypted_data, encryption_key)
            except Exception as e:
                logging.error(f"Decryption Error for FileId {file_id}: {e}")
                flash('خطأ في فك تشفير الملف')
                return render_template('Error.html')

            # Verify signature
            if signature and not verify_signature(decrypted_data, signature, public_key):
                logging.error(f"Signature verification failed for FileId {file_id}")
                flash('فشل التحقق من التوقيع الرقمي للملف')
                return render_template('Error.html')

            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('download_file', user[0], user[0])
            )
            conn.commit()
            logging.info(f"File {filename} downloaded, FileId: {file_id}")
            return send_file(BytesIO(decrypted_data), download_name=filename, as_attachment=True)
        else:
            logging.warning(f"File not found for FileId: {file_id}")
            return render_template('Error.html')
    except sqlite3.Error as e:
        logging.error(f"Database Error during file download: {e}")
        return render_template('Error.html')
    finally:
        conn.close()

# حذف ملف
@app.route('/deletefile/<int:file_id>')
def deletefile(file_id):
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for deletefile, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for deletefile, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role not in ['Manager', 'Admin']:
        logging.warning(f"User {user[0]} with role {role} attempted to delete file")
        flash('غير مسموح لك بحذف الملفات!')
        return render_template('Error.html')

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT FileName FROM Files WHERE FileId = ?", (file_id,))
        file = cursor.fetchone()
        if file:
            cursor.execute("DELETE FROM Files WHERE FileId = ?", (file_id,))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('delete_file', user[0], user[0])
            )
            conn.commit()
            logging.info(f"File {file[0]} deleted, FileId: {file_id}")
        else:
            logging.warning(f"File not found for FileId: {file_id}")
            flash('الملف غير موجود!')
    except sqlite3.Error as e:
        logging.error(f"Database Error during file deletion: {e}")
        conn.rollback()
        flash('حدث خطأ في حذف الملف، حاول مرة أخرى')
        return render_template('Error.html')
    finally:
        conn.close()
    return redirect(request.referrer)

# إدارة WorkID للأدمن
@app.route('/EditWorkID', methods=['POST', 'GET'])
def EditWorkID():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for EditWorkID, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for EditWorkID, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Admin':
        logging.warning(f"Non-admin user {user[0]} with role {role} attempted to access EditWorkID")
        flash('غير مسموح لك بالوصول إلى هذه الصفحة!')
        return render_template('Error.html')

    if request.method == 'POST':
        action = request.form.get('action')
        work_id = request.form.get('work_id')

        if action == 'add':
            if not re.match(r'^(A|U|M)\d{8}$', work_id):
                flash('معرف العمل يجب أن يبدأ بحرف A، U، أو M متبوع بـ 8 أرقام بالضبط!')
                logging.warning(f"Invalid WorkID format in EditWorkID: {work_id}")
            else:
                add_work_id(work_id)
                flash(f'تم إضافة معرف العمل {work_id} بنجاح!')
        elif action == 'delete':
            delete_work_id(work_id)
            flash(f'تم حذف معرف العمل {work_id} بنجاح!')

    work_ids = fetch_work_ids()
    return render_template('EditWorkID.html', work_ids=work_ids)

# إدارة WorkID للمدير
@app.route('/ManagerEditWorkID', methods=['POST', 'GET'])
def ManagerEditWorkID():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for ManagerEditWorkID, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for ManagerEditWorkID, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Manager':
        logging.warning(f"User {user[0]} with role {role} attempted to access ManagerEditWorkID")
        flash('غير مسموح لك بالوصول إلى هذه الصفحة!')
        return render_template('Error.html')

    if request.method == 'POST':
        action = request.form.get('action')
        work_id = request.form.get('work_id')

        if action == 'add':
            if not re.match(r'^(U|M)\d{8}$', work_id):
                flash('معرف العمل يجب أن يبدأ بحرف U أو M متبوع بـ 8 أرقام بالضبط!')
                logging.warning(f"Invalid WorkID format in ManagerEditWorkID: {work_id}")
            else:
                add_work_id(work_id)
                flash(f'تم إضافة معرف العمل {work_id} بنجاح!')
        elif action == 'delete':
            delete_work_id(work_id)
            flash(f'تم حذف معرف العمل {work_id} بنجاح!')

    work_ids = fetch_work_ids()
    return render_template('ManagerEditWorkID.html', work_ids=work_ids)

def add_work_id(work_id):
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID FROM ValidWorkID WHERE WORKID = ?", (work_id,))
        existing_row = cursor.fetchone()
        if existing_row:
            flash(f'معرف العمل {work_id} موجود بالفعل!')
            logging.warning(f"WorkID {work_id} already exists in ValidWorkID")
        else:
            cursor.execute("INSERT INTO ValidWorkID (WORKID) VALUES (?)", (work_id,))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('add_work_id', work_id, user[0])
            )
            conn.commit()
            logging.info(f"WorkID {work_id} added to ValidWorkID")
    except sqlite3.Error as e:
        logging.error(f"Database Error during add_work_id: {e}")
        conn.rollback()
        flash('حدث خطأ في إضافة معرف العمل، حاول مرة أخرى')
    finally:
        conn.close()

def delete_work_id(work_id):
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        if work_id == user[0]:
            flash('لا يمكن حذف معرف العمل الخاص بك!')
            logging.warning(f"Attempt to delete own WorkID {work_id} blocked")
            return
        cursor.execute("SELECT WORKID FROM ValidWorkID WHERE WORKID = ?", (work_id,))
        if cursor.fetchone():
            cursor.execute("DELETE FROM ValidWorkID WHERE WORKID = ?", (work_id,))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('delete_work_id', work_id, user[0])
            )
            conn.commit()
            logging.info(f"WorkID {work_id} deleted from ValidWorkID")
        else:
            flash(f'معرف العمل {work_id} غير موجود!')
            logging.warning(f"WorkID {work_id} not found in ValidWorkID")
    except sqlite3.Error as e:
        logging.error(f"Database Error during delete_work_id: {e}")
        conn.rollback()
        flash('حدث خطأ في حذف معرف العمل، حاول مرة أخرى')
    finally:
        conn.close()

def fetch_work_ids():
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID FROM ValidWorkID")
        work_ids = [row[0] for row in cursor.fetchall()]
        return work_ids
    except sqlite3.Error as e:
        logging.error(f"Database Error during fetch_work_ids: {e}")
        return []
    finally:
        conn.close()

# حذف مستخدم
@app.route('/DeleteUser', methods=['POST', 'GET'])
def DeleteUser():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for DeleteUser, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for DeleteUser, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Admin':
        logging.warning(f"Non-admin user {user[0]} with role {role} attempted to access DeleteUser")
        flash('غير مسموح لك بالوصول إلى هذه الصفحة!')
        return render_template('Error.html')

    if request.method == 'POST':
        work_id = request.form.get('work_id')
        if work_id == user[0]:
            flash('لا يمكنك حذف حسابك الخاص!')
            logging.warning(f"Admin {user[0]} attempted to delete own account")
            return redirect(url_for('DeleteUser'))
        delete_user(work_id)
        flash(f'تم حذف المستخدم {work_id} بنجاح!')
        return redirect(url_for('AdminMain'))

    users = fetch_user_names()
    return render_template('DeleteUser.html', users=users)

def fetch_user_names():
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID, First, Last, Role FROM Users")
        users = cursor.fetchall()
        return users
    except sqlite3.Error as e:
        logging.error(f"Database Error during fetch_user_names: {e}")
        return []
    finally:
        conn.close()

def delete_user(work_id):
    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID FROM Users WHERE WORKID = ?", (work_id,))
        if cursor.fetchone():
            cursor.execute("DELETE FROM Users WHERE WORKID = ?", (work_id,))
            cursor.execute("DELETE FROM Files WHERE WorkID = ?", (work_id,))
            cursor.execute("DELETE FROM ValidWorkID WHERE WORKID = ?", (work_id,))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('delete_user', work_id, user[0])
            )
            conn.commit()
            logging.info(f"User {work_id} deleted")
        else:
            flash(f'المستخدم {work_id} غير موجود!')
            logging.warning(f"User {work_id} not found")
    except sqlite3.Error as e:
        logging.error(f"Database Error during delete_user: {e}")
        conn.rollback()
        flash('حدث خطأ في حذف المستخدم، حاول مرة أخرى')
    finally:
        conn.close()

# البحث
@app.route("/search", methods=['POST', 'GET'])
def searched():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for search, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for search, user: {user[0]}")
        return render_template('TokenError.html')

    if request.method == "POST":
        conn = sqlite3.connect('database.db', timeout=10)
        try:
            searched = request.form["searched"]
            cur = conn.cursor()
            query = """
            SELECT FileId, FileName, WorkID
            FROM Files
            WHERE FileId LIKE ?
            OR FileName LIKE ? COLLATE NOCASE
            OR WorkID LIKE ?
            ORDER BY FileId DESC"""
            cur.execute(query, ('%' + searched + '%', '%' + searched + '%', '%' + searched + '%'))
            files = cur.fetchall()
            role = get_user_role(user[0])
            cursor = conn.cursor()
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('search', user[0], user[0])
            )
            conn.commit()
            return render_template(f'{role}MainPage.html', Files=files)
        except sqlite3.Error as e:
            logging.error(f"Database Error during search: {e}")
            conn.rollback()
            return render_template('Error.html')
        finally:
            conn.close()
    return redirect("/")

# تسجيل الدخول عبر Google
@app.route('/auth/google')
def google_login():
    redirect_uri = url_for('google_callback', _external=True)
    logging.debug(f"Redirecting to Google OAuth, redirect_uri: {redirect_uri}")
    return google.authorize_redirect(redirect_uri)

@app.route('/auth/google/callback')
def google_callback():
    try:
        token = google.authorize_access_token()
        logging.debug(f"Google access token received: {token}")
        resp = google.get('userinfo').json()
        logging.debug(f"Google user response: {resp}")

        email = resp.get('email')
        name = resp.get('name', 'Google User')
        work_id = f"G_{hashlib.sha256(email.encode()).hexdigest()[:8]}"
        logging.debug(f"Google user data: email={email}, name={name}, work_id={work_id}")

        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Users WHERE WORKID = ?", (work_id,))
            existing_user = cursor.fetchone()
            logging.debug(f"Existing user check for WorkID {work_id}: {existing_user}")

            if not existing_user:
                # Generate encryption and signature keys
                encryption_key, private_key, public_key = generate_keys()
                cursor.execute(
                    "INSERT INTO Users (WORKID, Password, First, Last, Role, secret_key, encryption_key, private_key, public_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (work_id, '', name.split()[0] if name and len(name.split()) > 0 else 'Google',
                     name.split()[-1] if name and len(name.split()) > 1 else 'User', 'User', None, encryption_key, private_key, public_key)
                )
                cursor.execute("INSERT INTO ValidWorkID (WORKID) VALUES (?)", (work_id,))
                cursor.execute(
                    "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                    ('signup_google', work_id, work_id)
                )
                conn.commit()
                logging.info(f"New Google user registered: {work_id}")

            user[0] = work_id
            session['pending_work_id'] = work_id
            logging.debug(f"Google login, WorkID: {work_id}, user[0]: {work_id}")

            cursor.execute("SELECT secret_key FROM Users WHERE WORKID = ?", (work_id,))
            secret_key = cursor.fetchone()[0]
        except sqlite3.Error as e:
            logging.error(f"Database Error during Google callback: {e}")
            conn.rollback()
            flash("خطأ في قاعدة البيانات، حاول مرة أخرى")
            return render_template('Error.html')
        finally:
            conn.close()

        if not secret_key:
            logging.debug(f"No 2FA secret for Google user {work_id}, redirecting to setup_2fa")
            return redirect(url_for('setup_2fa'))
        else:
            logging.debug(f"2FA secret found for Google user {work_id}, redirecting to verify_2fa")
            return redirect(url_for('verify_2fa'))

    except Exception as e:
        logging.error(f"Google Auth Error: {e}")
        flash(f"خطأ في تسجيل الدخول عبر Google: {str(e)}")
        return render_template('Error.html')

# تسجيل الدخول عبر GitHub
@app.route('/auth/github')
def github_login():
    redirect_uri = url_for('github_callback', _external=True)
    logging.debug(f"Redirecting to GitHub OAuth, redirect_uri: {redirect_uri}")
    return github.authorize_redirect(redirect_uri)

@app.route('/auth/github/callback')
def github_callback():
    try:
        token = github.authorize_access_token()
        logging.debug(f"GitHub access token received: {token}")
        resp = github.get('user').json()
        logging.debug(f"GitHub user response: {resp}")

        email = resp.get('email')
        if not email:
            emails = github.get('user/emails').json()
            logging.debug(f"GitHub emails response: {emails}")
            email = next((e['email'] for e in emails if e['primary'] and e['verified']), None)
            if not email:
                logging.error("No verified email found for GitHub user")
                flash("يرجى التأكد من أن لديك بريد إلكتروني عام أو مفعل في حساب GitHub")
                return redirect(url_for('login'))

        name = resp.get('name', 'GitHub User')
        work_id = f"GH_{hashlib.sha256(email.encode()).hexdigest()[:8]}"
        logging.debug(f"GitHub user data: email={email}, name={name}, work_id={work_id}")

        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Users WHERE WORKID = ?", (work_id,))
            existing_user = cursor.fetchone()
            logging.debug(f"Existing user check for WorkID {work_id}: {existing_user}")

            if not existing_user:
                # Generate encryption and signature keys
                encryption_key, private_key, public_key = generate_keys()
                cursor.execute(
                    "INSERT INTO Users (WORKID, Password, First, Last, Role, secret_key, encryption_key, private_key, public_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (work_id, '', name.split()[0] if name and len(name.split()) > 0 else 'GitHub',
                     name.split()[-1] if name and len(name.split()) > 1 else 'User', 'User', None, encryption_key, private_key, public_key)
                )
                cursor.execute("INSERT INTO ValidWorkID (WORKID) VALUES (?)", (work_id,))
                cursor.execute(
                    "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                    ('signup_github', work_id, work_id)
                )
                conn.commit()
                logging.info(f"New GitHub user registered: {work_id}")

            user[0] = work_id
            session['pending_work_id'] = work_id
            logging.debug(f"GitHub login, WorkID: {work_id}, user[0]: {work_id}")

            cursor.execute("SELECT secret_key FROM Users WHERE WORKID = ?", (work_id,))
            secret_key = cursor.fetchone()[0]
        except sqlite3.Error as e:
            logging.error(f"Database Error during GitHub callback: {e}")
            conn.rollback()
            flash("خطأ في قاعدة البيانات، حاول مرة أخرى")
            return render_template('Error.html')
        finally:
            conn.close()

        if not secret_key:
            logging.debug(f"No 2FA secret for GitHub user {work_id}, redirecting to setup_2fa")
            return redirect(url_for('setup_2fa'))
        else:
            logging.debug(f"2FA secret found for GitHub user {work_id}, redirecting to verify_2fa")
            return redirect(url_for('verify_2fa'))

    except Exception as e:
        logging.error(f"GitHub Auth Error: {e}")
        flash(f"خطأ في تسجيل الدخول عبر GitHub: {str(e)}")
        return render_template('Error.html')

# تسجيل الدخول عبر Okta
@app.route('/auth/okta')
def okta_login():
    redirect_uri = url_for('okta_callback', _external=True)
    logging.debug(f"Redirecting to Okta OAuth, redirect_uri: {redirect_uri}")
    return okta.authorize_redirect(redirect_uri)

@app.route('/auth/okta/callback')
def okta_callback():
    try:
        token = okta.authorize_access_token()
        logging.debug(f"Okta access token received: {token}")
        resp = okta.get('userinfo').json()
        logging.debug(f"Okta user response: {resp}")

        email = resp.get('email')
        if not email:
            logging.error("No email found for Okta user")
            flash("يرجى التأكد من أن لديك بريد إلكتروني مفعل في حساب Okta")
            return redirect(url_for('login'))

        name = resp.get('name', 'Okta User')
        work_id = f"OK_{hashlib.sha256(email.encode()).hexdigest()[:8]}"
        logging.debug(f"Okta user data: email={email}, name={name}, work_id={work_id}")

        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Users WHERE WORKID = ?", (work_id,))
            existing_user = cursor.fetchone()
            logging.debug(f"Existing user check for WorkID {work_id}: {existing_user}")

            if not existing_user:
                # Generate encryption and signature keys
                encryption_key, private_key, public_key = generate_keys()
                cursor.execute(
                    "INSERT INTO Users (WORKID, Password, First, Last, Role, secret_key, encryption_key, private_key, public_key) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (work_id, '', name.split()[0] if name and len(name.split()) > 0 else 'Okta',
                     name.split()[-1] if name and len(name.split()) > 1 else 'User', 'User', None, encryption_key, private_key, public_key)
                )
                cursor.execute("INSERT INTO ValidWorkID (WORKID) VALUES (?)", (work_id,))
                cursor.execute(
                    "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                    ('signup_okta', work_id, work_id)
                )
                conn.commit()
                logging.info(f"New Okta user registered: {work_id}")

            user[0] = work_id
            session['pending_work_id'] = work_id
            logging.debug(f"Okta login, WorkID: {work_id}, user[0]: {work_id}")

            cursor.execute("SELECT secret_key FROM Users WHERE WORKID = ?", (work_id,))
            secret_key = cursor.fetchone()[0]
        except sqlite3.Error as e:
            logging.error(f"Database Error during Okta callback: {e}")
            conn.rollback()
            flash("خطأ في قاعدة البيانات، حاول مرة أخرى")
            return render_template('Error.html')
        finally:
            conn.close()

        if not secret_key:
            logging.debug(f"No 2FA secret for Okta user {work_id}, redirecting to setup_2fa")
            return redirect(url_for('setup_2fa'))
        else:
            logging.debug(f"2FA secret found for Okta user {work_id}, redirecting to verify_2fa")
            return redirect(url_for('verify_2fa'))

    except Exception as e:
        logging.error(f"Okta Auth Error: {e}")
        flash(f"خطأ في تسجيل الدخول عبر Okta: {str(e)}")
        return render_template('Error.html')

# تعديل بيانات المستخدم
@app.route('/EditUser/<work_id>', methods=['GET', 'POST'])
def EditUser(work_id):
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for EditUser, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for EditUser, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Admin':
        logging.warning(f"Non-admin user {user[0]} with role {role} attempted to access EditUser")
        flash('غير مسموح لك بالوصول إلى هذه الصفحة!')
        return render_template('Error.html')

    conn = sqlite3.connect('database.db', timeout=10)
    try:
        cursor = conn.cursor()
        cursor.execute("SELECT WORKID, First, Last, Role FROM Users WHERE WORKID = ?", (work_id,))
        user_data = cursor.fetchone()
        if not user_data:
            flash('معرف العمل غير موجود!')
            logging.warning(f"WorkID {work_id} not found in Users for EditUser")
            return redirect(url_for('ManagePermissions'))

        if request.method == 'POST':
            first_name = request.form.get('first_name')
            last_name = request.form.get('last_name')
            new_work_id = request.form.get('work_id')
            password = request.form.get('password')
            confirm_password = request.form.get('confirm_password')

            if not all([first_name, last_name, new_work_id]):
                flash('يرجى ملء جميع الحقول الإلزامية!')
                logging.warning(f"Missing fields for EditUser, WorkID: {work_id}")
                return render_template('EditUser.html', user=user_data)

            if password and password != confirm_password:
                flash('كلمات المرور غير متطابقة!')
                logging.warning(f"Password mismatch for EditUser, WorkID: {work_id}")
                return render_template('EditUser.html', user=user_data)

            if not re.match(r'^(A|U|M)\d{8}$', new_work_id):
                flash('معرف العمل يجب أن يبدأ بحرف A، U، أو M متبوع بـ 8 أرقام بالضبط!')
                logging.warning(f"Invalid WorkID format for EditUser: {new_work_id}")
                return render_template('EditUser.html', user=user_data)

            role_prefix_map = {'Admin': 'A', 'Manager': 'M', 'User': 'U'}
            if not new_work_id.startswith(role_prefix_map[user_data[3]]):
                flash(f'معرف العمل يجب أن يبدأ بحرف {role_prefix_map[user_data[3]]} لدور {user_data[3]}!')
                logging.warning(f"WorkID {new_work_id} does not match role {user_data[3]}")
                return render_template('EditUser.html', user=user_data)

            if new_work_id != work_id:
                cursor.execute("SELECT WORKID FROM Users WHERE WORKID = ?", (new_work_id,))
                if cursor.fetchone():
                    flash(f'معرف العمل الجديد {new_work_id} مستخدم بالفعل!')
                    logging.warning(f"New WorkID {new_work_id} already exists in Users")
                    return render_template('EditUser.html', user=user_data)
                cursor.execute("SELECT WORKID FROM ValidWorkID WHERE WORKID = ?", (new_work_id,))
                if cursor.fetchone():
                    flash(f'معرف العمل الجديد {new_work_id} موجود بالفعل في قائمة معرفات العمل!')
                    logging.warning(f"New WorkID {new_work_id} already exists in ValidWorkID")
                    return render_template('EditUser.html', user=user_data)

            update_query = "UPDATE Users SET First = ?, Last = ?, WORKID = ?"
            update_params = [first_name, last_name, new_work_id]
            if password:
                hashed_password = hashlib.sha256(password.encode()).hexdigest()
                update_query += ", Password = ?"
                update_params.append(hashed_password)
            update_query += " WHERE WORKID = ?"
            update_params.append(work_id)

            cursor.execute(update_query, update_params)
            if new_work_id != work_id:
                cursor.execute("UPDATE ValidWorkID SET WORKID = ? WHERE WORKID = ?", (new_work_id, work_id))
                cursor.execute("UPDATE Files SET WorkID = ? WHERE WorkID = ?", (new_work_id, work_id))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('edit_user', new_work_id, user[0])
            )
            conn.commit()
            flash(f'تم تحديث بيانات المستخدم {new_work_id} بنجاح!')
            logging.info(f"User {work_id} updated to new WorkID: {new_work_id}, First: {first_name}, Last: {last_name}")
            return redirect(url_for('ManagePermissions'))

        return render_template('EditUser.html', user=user_data)

    except sqlite3.Error as e:
        logging.error(f"Database Error during EditUser: {e}")
        conn.rollback()
        flash('حدث خطأ في تحديث بيانات المستخدم، حاول مرة أخرى')
        return render_template('Error.html')
    finally:
        conn.close()

# إدارة صلاحيات المستخدمين
@app.route('/ManagePermissions', methods=['POST', 'GET'])
def ManagePermissions():
    session_token = request.cookies.get('AuthToken')
    logging.debug(f"Checking token for ManagePermissions, token: {session_token}, user: {user[0]}")
    if not session_token or not check_token(session_token, user[0]):
        logging.warning(f"Invalid or no token for ManagePermissions, user: {user[0]}")
        return render_template('TokenError.html')

    role = get_user_role(user[0])
    if role != 'Admin':
        logging.warning(f"Non-admin user {user[0]} with role {role} attempted to access ManagePermissions")
        flash('غير مسموح لك بالوصول إلى هذه الصفحة!')
        return render_template('Error.html')

    if request.method == 'POST':
        work_id = request.form.get('work_id')
        new_role = request.form.get('role')
        change_workid_prefix = request.form.get('change_workid_prefix') == '1'

        if work_id == user[0]:
            flash('لا يمكنك تغيير دورك الخاص!')
            logging.warning(f"Admin {user[0]} attempted to change own role")
            return redirect(url_for('ManagePermissions'))

        if not work_id or not new_role:
            flash('يرجى اختيار معرف المستخدم والدور!')
            logging.warning(f"Missing work_id or role in ManagePermissions")
            return redirect(url_for('ManagePermissions'))

        if new_role not in ['User', 'Admin', 'Manager']:
            flash('دور غير صالح!')
            logging.warning(f"Invalid role selected: {new_role}")
            return redirect(url_for('ManagePermissions'))

        conn = sqlite3.connect('database.db', timeout=10)
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT WORKID, Role FROM Users WHERE WORKID = ?", (work_id,))
            user_data = cursor.fetchone()
            if not user_data:
                flash('معرف العمل غير موجود!')
                logging.warning(f"WorkID {work_id} not found in Users")
                return redirect(url_for('ManagePermissions'))

            old_role = user_data[1]
            new_work_id = work_id

            role_prefix_map = {'Admin': 'A', 'Manager': 'M', 'User': 'U'}
            if change_workid_prefix and not work_id.startswith(role_prefix_map[new_role]):
                new_work_id = role_prefix_map[new_role] + work_id[1:]
                cursor.execute("SELECT WORKID FROM Users WHERE WORKID = ?", (new_work_id,))
                if cursor.fetchone():
                    flash(f'معرف العمل الجديد {new_work_id} مستخدم بالفعل!')
                    logging.warning(f"New WorkID {new_work_id} already exists")
                    return redirect(url_for('ManagePermissions'))
                cursor.execute("SELECT WORKID FROM ValidWorkID WHERE WORKID = ?", (new_work_id,))
                if cursor.fetchone():
                    flash(f'معرف العمل الجديد {new_work_id} موجود بالفعل في قائمة معرفات العمل!')
                    logging.warning(f"New WorkID {new_work_id} already exists in ValidWorkID")
                    return redirect(url_for('ManagePermissions'))

            elif not change_workid_prefix:
                if not work_id.startswith(role_prefix_map[new_role]):
                    flash(f'معرف العمل يجب أن يبدأ بحرف {role_prefix_map[new_role]} أو اختر تغيير أول حرف!')
                    logging.warning(f"WorkID {work_id} does not match role {new_role}")
                    return redirect(url_for('ManagePermissions'))

            cursor.execute('''
                INSERT INTO RoleChangeLog (work_id, old_role, new_role, changed_by)
                VALUES (?, ?, ?, ?)
            ''', (work_id, old_role, new_role, user[0]))
            cursor.execute("UPDATE Users SET Role = ?, WORKID = ? WHERE WORKID = ?", (new_role, new_work_id, work_id))
            if new_work_id != work_id:
                cursor.execute("UPDATE ValidWorkID SET WORKID = ? WHERE WORKID = ?", (new_work_id, work_id))
                cursor.execute("UPDATE Files SET WorkID = ? WHERE WorkID = ?", (new_work_id, work_id))
            cursor.execute(
                "INSERT INTO UserManagementLog (action, work_id, performed_by) VALUES (?, ?, ?)",
                ('change_role', new_work_id, user[0])
            )
            conn.commit()
            flash(f'تم تحديث دور المستخدم {new_work_id} إلى {new_role} بنجاح!')
            logging.info(f"Role updated for WorkID {work_id} to {new_role}, new WorkID: {new_work_id}")
        except sqlite3.Error as e:
            logging.error(f"Database Error during role update: {e}")
            conn.rollback()
            flash('حدث خطأ في تحديث الدور، حاول مرة أخرى')
            return render_template('Error.html')
        finally:
            conn.close()

    users = fetch_user_names()
    return render_template('ManagePermissions.html', users=users)

# تشغيل التطبيق
if __name__ == "__main__":
    start_db()
    update_user_keys()  # تحديث مفاتيح المستخدمين الحاليين
app.run(debug=True, ssl_context=('cert.pem', 'key.pem'), host='0.0.0.0', port=443)