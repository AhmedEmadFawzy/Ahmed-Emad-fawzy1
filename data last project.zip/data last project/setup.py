import sqlite3
import logging

logging.basicConfig(level=logging.DEBUG)

def start_db():
    conn = sqlite3.connect('database.db', timeout=10)
    cursor = conn.cursor()
    
    try:
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Users (
                WORKID TEXT PRIMARY KEY,
                Password TEXT,
                First TEXT NOT NULL,
                Last TEXT NOT NULL,
                Role TEXT NOT NULL CHECK(Role IN ('User', 'Admin', 'Manager')),
                secret_key TEXT,
                encryption_key BLOB,
                private_key BLOB,
                public_key BLOB
            )
        ''')
        logging.info("Table Users created or already exists")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS Files (
                FileId INTEGER PRIMARY KEY AUTOINCREMENT,
                FileName TEXT NOT NULL,
                FileData BLOB NOT NULL,
                WorkID TEXT NOT NULL,
                Signature BLOB,
                FOREIGN KEY (WorkID) REFERENCES Users(WORKID)
            )
        ''')
        logging.info("Table Files created or already exists")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ValidWorkID (
                WORKID TEXT PRIMARY KEY
            )
        ''')
        logging.info("Table ValidWorkID created or already exists")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS UserManagementLog (
                LogId INTEGER PRIMARY KEY AUTOINCREMENT,
                action TEXT NOT NULL,
                work_id TEXT NOT NULL,
                performed_by TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (work_id) REFERENCES Users(WORKID),
                FOREIGN KEY (performed_by) REFERENCES Users(WORKID)
            )
        ''')
        logging.info("Table UserManagementLog created or already exists")

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS RoleChangeLog (
                LogId INTEGER PRIMARY KEY AUTOINCREMENT,
                work_id TEXT NOT NULL,
                old_role TEXT NOT NULL,
                new_role TEXT NOT NULL,
                changed_by TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (work_id) REFERENCES Users(WORKID),
                FOREIGN KEY (changed_by) REFERENCES Users(WORKID)
            )
        ''')
        logging.info("Table RoleChangeLog created or already exists")

        default_work_ids = [
            'A12345678',
            'M12345678',
            'U12345678',
            'U87654321',
            'A11223344',
        ]

        for work_id in default_work_ids:
            cursor.execute('''
                INSERT OR IGNORE INTO ValidWorkID (WORKID)
                VALUES (?)
            ''', (work_id,))
        logging.info("Default WorkIDs inserted or already exist")

        conn.commit()
        logging.info("Database setup completed successfully")

    except sqlite3.Error as e:
        logging.error(f"Database Error during setup: {e}")
        conn.rollback()
        raise
    finally:
        conn.close()
        logging.debug("Database connection closed")

if __name__ == "__main__":
    start_db()