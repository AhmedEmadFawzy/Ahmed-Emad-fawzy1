import sqlite3
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
import os
import logging

logging.basicConfig(level=logging.DEBUG)

def generate_encryption_key():
    return os.urandom(32)  # مفتاح AES بطول 256 بت

def generate_rsa_keys():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKey
    )
    return private_pem, public_pem

# الاتصال بقاعدة البيانات
conn = sqlite3.connect('database.db', timeout=10)
cursor = conn.cursor()

try:
    # التحقق من وجود المستخدم
    cursor.execute("SELECT WORKID FROM Users WHERE WORKID = ?", ('A11223344',))
    if not cursor.fetchone():
        logging.error("User A11223344 not found in Users table")
        print("المستخدم غير موجود. أنشئ مستخدمًا جديدًا.")
        exit()

    # إنشاء مفاتيح جديدة
    encryption_key = generate_encryption_key()
    private_key_pem, public_key_pem = generate_rsa_keys()
    logging.debug(f"Generated new keys: encryption_key={len(encryption_key)} bytes, private_key={len(private_key_pem)} bytes, public_key={len(public_key_pem)} bytes")

    # تحديث سجل المستخدم
    cursor.execute(
        """
        UPDATE Users
        SET encryption_key = ?, private_key = ?, public_key = ?
        WHERE WORKID = ?
        """,
        (encryption_key, private_key_pem, public_key_pem, 'A11223344')
    )
    conn.commit()
    logging.info("User A11223344 updated with new encryption keys")

except sqlite3.Error as e:
    logging.error(f"Database Error: {e}")
    conn.rollback()
finally:
    conn.close()