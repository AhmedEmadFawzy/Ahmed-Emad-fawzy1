import sqlite3

conn = sqlite3.connect('A:/Secure-Document-Management-System-main/database.db')
cursor = conn.cursor()

# WorkIDs للـ Admin
work_ids = [
    ('A12345678',), ('A12345679',), ('A12345680',)    ,
    # WorkIDs للـ User
    ('U12345678',), ('U12345679',), ('U12345680',),
    # WorkIDs للـ Manager
    ('M12345678',), ('M12345679',), ('M12345680',)
]

for work_id in work_ids:
    cursor.execute("INSERT OR IGNORE INTO ValidWorkID (WORKID) VALUES (?)", work_id)

conn.commit()
conn.close()
print("WorkIDs added successfully!")