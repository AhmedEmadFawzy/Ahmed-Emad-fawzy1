import jwt
import datetime

SECRET_KEY = "your_jwt_secret_key"  # استبدل بمفتاح سري آمن

def generate_token(work_id):
    payload = {
        'work_id': work_id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1)
    }
    token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')
    return token

def check_token(token, work_id):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=['HS256'])
        return payload['work_id'] == work_id
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False